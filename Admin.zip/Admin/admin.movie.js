var movieId = document.getElementById("MovieId");
movieId.value = 1;
var number ;



  
